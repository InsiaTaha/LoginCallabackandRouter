import React from "react";
export default function About() {
  return <div>About page</div>;
}
