import React,{useState,useEffect} from "react";
import "./NavbarStyle.css";
import Signup from './Signup';
import Signout from './Signout'
import Login from './Login'
import { BrowserRouter , Route, Routes,Link, useNavigate } from "react-router-dom";
import { QueryClient, QueryClientProvider, useQuery } from 'react-query'



export default function Dashboard() {
  const [userNameLogin,setUserLogin] = useState('')
  const queryClient = new QueryClient();
 
  function Listener(data) {
    if(data != "")
    {
    setUserLogin(data);
    }
  }
  function hello() {
   
   setUserLogin("");

    
  }
  return (
   
    <BrowserRouter>
     <div className="Nav">
     <div className="navbar">
          <ul className="nav-links">
          <li>
              <Link to="/">Dashboard </Link>
            </li>
            {userNameLogin != '' ? (
               <li>
               <Link to="/Signout" onClick={hello}>Signout </Link>
             </li>
            ): (
           <li>
           <Link to="/Signup">Signup </Link>
         </li>
         
         )
        }
          </ul>
          </div>
        <Routes>
        <Route index element={<LoginDisplay setUserSession={(data)=>Listener(data)}/>}/>
        {userNameLogin != '' ? (
          <Route path="/Signout" element={<Signout/>}/>
        ): (
           <Route path="/Signup" element={<Signup/>} />
         )
        }
           
       
        </Routes>
    </div>
  </BrowserRouter>

  );
}



export function LoginDisplay({setUserSession}) {
    
  const queryClient = new QueryClient();
  const [userName,setUserName] = useState('');
  const [FirstName,setFirstName] = useState('');
  const [LastName,setLastName] = useState('');
  const navigate=useNavigate();


  function showData() {
    if (userName) {
      return( 
        <>
        <div className="Dashboard">
        <h1>You are Loggged in!</h1>
        <h3>Welcome {FirstName} {LastName} </h3>
        <h4>Your UserID is {userName}</h4>
        </div>
        </>)
    }
    else {
      return(<QueryClientProvider client={queryClient}>
       <Login getUserName={(data)=>Listener(data)}/>
     </QueryClientProvider>)
    }
  }



  function Listener(data) {
    console.log(data)
    setFirstName(data.FName);
    setLastName(data.LName);
    setUserName(data.UName);
  }

   
  

return(<>
       { setUserSession(userName)}
       {showData()}</>
     )
}



