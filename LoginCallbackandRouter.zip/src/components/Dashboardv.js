import React from "react";
import Navbar from './Navbar'
import { useState, useEffect, useContext } from "react";


export default function Dashboard(){
 
    const [userName,setUserName] = useState('')
    const [password, setPassword] = useState('')
    
    function Listener(data) {
      setUserName(data.userName);
      setPassword(data.password);
    }
  
    function showData() {
      if (userName && password) {
        return <>Welcome {userName}</>
      }
      else {
        return<>Username not set</>
      }
    }
  
    function onLogoutClicked() {
      setUserName('');
      setPassword('');
    }
  
    return <>
      {/* <ChildComponent callback={(data) => Listener(data)} />
      <br/>
      {showData()}
      <br />
      <button onClick={onLogoutClicked}>Log out</button> */}
    </>
  }