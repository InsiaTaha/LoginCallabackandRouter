import { useState, useEffect, useContext } from "react";
import axios from 'axios';
import { QueryClient, QueryClientProvider, useQuery } from 'react-query'
import { useMutation } from 'react-query';
import './login.css'



const Login = ({getUserName}) => {
  const [user, setUser] = useState("");
  const [pwd, setPwd] = useState("");
  const [errMsg, setErrMsg] = useState("");
  const [success, setSuccess] = useState(false);

  const mutation = useMutation(
    newUserRecord => {
       return axios.get('http://localhost:3000/UserRecord?UName='+user+'&Password='+pwd).then((resp) => { 
        if(resp.data[0] != null)
        {
          setSuccess(true);
          getUserName(resp.data[0])
          console.log(resp.data[0])
        }
        else{
          alert("Please Enter a Valid Username and Password");
        }
      });
    }
  )

 
  return (
    <>
      {success ? (
        <section>
          <h1></h1>
          <br />
          <p>{/* <a href="#">Go to Home</a> */}</p>
        </section>
      ) : (
        <section>
          <p
            //ref={errRef}
            className={errMsg ? "errmsg" : "offscreen"}
            aria-live="assertive"
          >
            {errMsg}
          </p>
          
          <form>
          <h1 className="space">Login</h1>
            <label htmlFor="username">Username:</label>
            <input
              type="text"
              id="username"
              //ref={userRef}
              autoComplete="off"
              onChange={(e) => setUser(e.target.value)}
              value={user}
              required
            />
            <p className="space"></p>
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              onChange={(e) => setPwd(e.target.value)}
              value={pwd}
              required
            />
             <p className="space"></p>
               <div className="footer">
          {mutation.isLoading ? (
          'Please Wait!...'
        ) : (
          <>
            {mutation.isError ? (
              <div>An error occurred: {mutation.error.message}</div>
            ) : null}
  
            {mutation.isSuccess ? <div>Login SucessFull</div> : null}
  
            <button
              onClick={() => {
                mutation.mutate()
              }}
            >
              Login
            </button>
            {/* <button type="submit"  onClick={handleSubmit} className="btn">Ok</button> */}
          </>
        )}
              
          </div>
          <p>
          </p>
          </form>
         
        </section>
      )}
    </>
  );
      }
export default  Login