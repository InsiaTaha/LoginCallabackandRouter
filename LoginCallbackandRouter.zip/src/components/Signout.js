import React,{useState,useEffect} from "react";

import Signup from './Signup';
import Login from './Login'
import { BrowserRouter , Route, Routes,Link, useNavigate } from "react-router-dom";
import { QueryClient, QueryClientProvider, useQuery } from 'react-query'

export default function Logout() {
    
    const queryClient = new QueryClient();
    const [userName,setUserName] = useState('');
    const [FirstName,setFirstName] = useState('');
    const [LastName,setLastName] = useState('');
  const navigate=useNavigate();




  
  return(<>

       
         </>
       )
  }
  